-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: mantenimiento_bacal
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anuncios`
--

DROP TABLE IF EXISTS `anuncios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anuncios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) NOT NULL,
  `contenido` text NOT NULL,
  `tipo` enum('info','aviso','urgente','exito') NOT NULL DEFAULT 'info',
  `icono` varchar(50) DEFAULT 'megaphone',
  `sucursal_id` int(11) DEFAULT NULL,
  `rol_id` int(11) DEFAULT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date DEFAULT NULL COMMENT 'NULL = sin fecha límite',
  `fijado` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 = se fija arriba',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_por_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activo_vigencia` (`activo`,`fecha_inicio`,`fecha_fin`),
  KEY `idx_sucursal` (`sucursal_id`),
  KEY `idx_rol` (`rol_id`),
  KEY `fk_anun_creador` (`creado_por_id`),
  CONSTRAINT `fk_anun_creador` FOREIGN KEY (`creado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_anun_rol` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_anun_sucursal` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anuncios`
--

LOCK TABLES `anuncios` WRITE;
/*!40000 ALTER TABLE `anuncios` DISABLE KEYS */;
/*!40000 ALTER TABLE `anuncios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `anuncios_lecturas`
--

DROP TABLE IF EXISTS `anuncios_lecturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anuncios_lecturas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anuncio_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `leido_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_anuncio_usuario` (`anuncio_id`,`usuario_id`),
  KEY `idx_usuario` (`usuario_id`),
  CONSTRAINT `fk_lect_anuncio` FOREIGN KEY (`anuncio_id`) REFERENCES `anuncios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lect_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anuncios_lecturas`
--

LOCK TABLES `anuncios_lecturas` WRITE;
/*!40000 ALTER TABLE `anuncios_lecturas` DISABLE KEYS */;
/*!40000 ALTER TABLE `anuncios_lecturas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `areas`
--

DROP TABLE IF EXISTS `areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `areas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `color` varchar(20) DEFAULT '#6B7280',
  `icono` varchar(50) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` datetime DEFAULT current_timestamp(),
  `actualizado_en` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `areas`
--

LOCK TABLES `areas` WRITE;
/*!40000 ALTER TABLE `areas` DISABLE KEYS */;
INSERT INTO `areas` VALUES (20,'Recepción de carne',NULL,'#0EA5E9',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(21,'Cámaras frigoríficas',NULL,'#06B6D4',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(22,'Sala de despiece',NULL,'#DC2626',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(23,'Línea de empaque',NULL,'#8B5CF6',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(24,'Línea de embutidos',NULL,'#7C3AED',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(25,'Hornos y ahumadores',NULL,'#F59E0B',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(26,'Cuarto de máquinas',NULL,'#0F766E',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(27,'Cuarto eléctrico',NULL,'#EAB308',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(28,'Tratamiento de agua',NULL,'#3B82F6',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(29,'Calderas',NULL,'#B91C1C',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(30,'Sistema de vapor',NULL,'#991B1B',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(31,'Andén de carga/descarga',NULL,'#71717A',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(32,'Oficinas',NULL,'#475569',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(33,'Taller de mantenimiento',NULL,'#374151',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(34,'Estacionamiento',NULL,'#52525B',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(35,'Áreas comunes',NULL,'#9CA3AF',NULL,1,'2026-05-28 16:10:57','2026-05-28 16:10:57'),(36,'Area de chorizo','Sotano en Bacal1, al lado de la camara 3','#6B7280',NULL,1,'2026-06-01 13:14:58','2026-06-01 13:14:58'),(37,'Area de bombeo de red hidraulica','Inluye bombas de presion de agua para el edificio , sistema de filtracion de agua y boilers','#6B7280',NULL,1,'2026-06-01 14:25:05','2026-06-01 14:25:05');
/*!40000 ALTER TABLE `areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditoria_sistema`
--

DROP TABLE IF EXISTS `auditoria_sistema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditoria_sistema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `accion` varchar(100) NOT NULL,
  `entidad` varchar(50) DEFAULT NULL,
  `entidad_id` int(11) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `creado_en` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_accion` (`accion`),
  KEY `idx_fecha` (`creado_en`),
  CONSTRAINT `auditoria_sistema_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria_sistema`
--

LOCK TABLES `auditoria_sistema` WRITE;
/*!40000 ALTER TABLE `auditoria_sistema` DISABLE KEYS */;
INSERT INTO `auditoria_sistema` VALUES (57,1,'login',NULL,NULL,'Inicio de sesión exitoso','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 16:28:04'),(58,1,'logout',NULL,NULL,'Cierre de sesión','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 16:28:06'),(59,1,'login',NULL,NULL,'Inicio de sesión exitoso','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 16:28:12'),(60,1,'cambio_password','usuarios',1,'Cambio de contraseña','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 16:28:29'),(61,1,'logout',NULL,NULL,'Cierre de sesión','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 16:28:33'),(62,1,'login',NULL,NULL,'Inicio de sesión exitoso','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 16:28:39'),(63,1,'crear_refaccion','refacciones',1,'Rodamiento 6205','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 16:48:32'),(67,1,'login',NULL,NULL,'Inicio de sesión exitoso','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 21:34:49'),(68,1,'movimiento_refaccion','refacciones_movimientos',3,'Entrada · refaccion=1 cantidad=10','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 21:35:54'),(69,1,'crear_equipo','equipos',1,'Equipo BAC-001','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 21:38:43'),(70,1,'crear_incidencia','incidencias',37,'Folio INC-BAC-2026-0001','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 21:39:36'),(71,1,'crear_componente','equipo_componentes',1,'motor','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 21:50:20'),(72,1,'refaccion_en_incidencia','incidencia_refacciones',37,'Refacción id=1 cant=1','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 21:52:52'),(73,1,'login',NULL,NULL,'Inicio de sesión exitoso','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-29 10:49:57'),(74,1,'crear_herramienta','herramientas',1,'Martillo de prueba','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-29 10:51:04'),(75,1,'crear_usuario','usuarios',17,'Usuario lfrodriguez creado','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-29 10:52:54'),(76,1,'prestar_herramienta','herramientas_prestamos',1,'Préstamo de herramienta 1 a usuario 17','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-29 10:53:19'),(77,1,'devolver_herramienta','herramientas_prestamos',1,'Devolución condición: buena','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-29 10:53:43'),(78,1,'editar_usuario','usuarios',1,'Usuario admin editado','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-29 11:02:42'),(79,1,'login',NULL,NULL,'Inicio de sesión exitoso','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-31 07:46:59'),(80,1,'login',NULL,NULL,'Inicio de sesión exitoso','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-31 10:23:51'),(81,1,'logout',NULL,NULL,'Cierre de sesión','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-31 10:40:00'),(82,1,'logout',NULL,NULL,'Cierre de sesión','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-31 14:19:05'),(83,1,'logout',NULL,NULL,'Cierre de sesión','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-01 11:54:06'),(84,1,'crear_area','areas',36,'Área Area de chorizo','192.168.1.54','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-01 13:14:58'),(85,1,'crear_area','areas',37,'Área Area de bombeo de red hidraulica','192.168.1.54','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-01 14:25:05'),(86,1,'crear_incidencia','incidencias',38,'Folio INC-BAC-2026-0002','192.168.1.54','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-01 14:29:36'),(87,1,'login',NULL,NULL,'Inicio de sesión exitoso','192.168.1.84','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-01 15:05:45'),(88,1,'login',NULL,NULL,'Inicio de sesión exitoso','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-01 16:27:08'),(89,1,'logout',NULL,NULL,'Cierre de sesión','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-01 16:30:19'),(90,1,'login',NULL,NULL,'Inicio de sesión exitoso','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-01 16:33:06'),(91,1,'crear_usuario','usuarios',18,'Usuario njmartinez creado','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-01 16:34:25'),(92,1,'crear_usuario','usuarios',19,'Usuario jamartinez creado','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-01 16:35:21'),(93,1,'crear_usuario','usuarios',20,'Usuario jlcorral creado','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-01 16:36:24');
/*!40000 ALTER TABLE `auditoria_sistema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups_realizados`
--

DROP TABLE IF EXISTS `backups_realizados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups_realizados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_archivo` varchar(255) NOT NULL,
  `tamano_bytes` bigint(20) NOT NULL DEFAULT 0,
  `tipo` enum('manual','automatico') NOT NULL DEFAULT 'manual',
  `realizado_por_id` int(11) DEFAULT NULL COMMENT 'Null si fue automatico',
  `notas` varchar(255) DEFAULT NULL,
  `exitoso` tinyint(1) NOT NULL DEFAULT 1,
  `mensaje_error` text DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_creado` (`creado_en`),
  KEY `fk_backup_usuario` (`realizado_por_id`),
  CONSTRAINT `fk_backup_usuario` FOREIGN KEY (`realizado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups_realizados`
--

LOCK TABLES `backups_realizados` WRITE;
/*!40000 ALTER TABLE `backups_realizados` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups_realizados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `color` varchar(20) DEFAULT '#6B7280',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (13,'Mecánica',NULL,'#DC2626',1,'2026-05-28 16:10:57'),(14,'Eléctrica',NULL,'#F59E0B',1,'2026-05-28 16:10:57'),(15,'Electrónica/Control',NULL,'#7C3AED',1,'2026-05-28 16:10:57'),(16,'Hidráulica',NULL,'#3B82F6',1,'2026-05-28 16:10:57'),(17,'Neumática',NULL,'#10B981',1,'2026-05-28 16:10:57'),(18,'Refrigeración',NULL,'#06B6D4',1,'2026-05-28 16:10:57'),(19,'Vapor y calderas',NULL,'#991B1B',1,'2026-05-28 16:10:57'),(20,'Soldadura',NULL,'#EA580C',1,'2026-05-28 16:10:57'),(21,'Lubricación',NULL,'#84CC16',1,'2026-05-28 16:10:57'),(22,'Limpieza industrial',NULL,'#EC4899',1,'2026-05-28 16:10:57'),(23,'Edificación/Civil',NULL,'#71717a',1,'2026-05-28 16:10:57'),(24,'Seguridad industrial',NULL,'#EF4444',1,'2026-05-28 16:10:57'),(25,'Instrumentación',NULL,'#0891B2',1,'2026-05-28 16:10:57'),(26,'Tratamiento de agua',NULL,'#0284C7',1,'2026-05-28 16:10:57'),(27,'Otro',NULL,'#525252',1,'2026-05-28 16:10:57');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias_palabras_clave`
--

DROP TABLE IF EXISTS `categorias_palabras_clave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias_palabras_clave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_id` int(11) NOT NULL,
  `palabra` varchar(60) NOT NULL COMMENT 'Palabra o frase clave (lowercase, sin acentos)',
  `peso` int(11) NOT NULL DEFAULT 1 COMMENT 'Mayor peso = más específica',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cat_palabra` (`categoria_id`,`palabra`),
  KEY `idx_palabra` (`palabra`),
  CONSTRAINT `fk_kw_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias_palabras_clave`
--

LOCK TABLES `categorias_palabras_clave` WRITE;
/*!40000 ALTER TABLE `categorias_palabras_clave` DISABLE KEYS */;
INSERT INTO `categorias_palabras_clave` VALUES (89,13,'rodamiento',3,'2026-05-28 23:10:57'),(90,13,'cojinete',3,'2026-05-28 23:10:57'),(91,13,'banda',3,'2026-05-28 23:10:57'),(92,13,'cadena',3,'2026-05-28 23:10:57'),(93,13,'engrane',3,'2026-05-28 23:10:57'),(94,13,'piñon',3,'2026-05-28 23:10:57'),(95,13,'polea',3,'2026-05-28 23:10:57'),(96,13,'eje',2,'2026-05-28 23:10:57'),(97,13,'motor',2,'2026-05-28 23:10:57'),(98,13,'reductor',3,'2026-05-28 23:10:57'),(99,13,'flecha',2,'2026-05-28 23:10:57'),(100,13,'tornillo',1,'2026-05-28 23:10:57'),(101,13,'desgaste',2,'2026-05-28 23:10:57'),(102,13,'vibracion',3,'2026-05-28 23:10:57'),(103,13,'ruido',2,'2026-05-28 23:10:57'),(104,13,'rotura',3,'2026-05-28 23:10:57'),(105,13,'fractura',3,'2026-05-28 23:10:57'),(106,13,'desbalance',3,'2026-05-28 23:10:57'),(107,13,'alineacion',3,'2026-05-28 23:10:57'),(120,14,'corto circuito',3,'2026-05-28 23:10:57'),(121,14,'fusible',3,'2026-05-28 23:10:57'),(122,14,'breaker',3,'2026-05-28 23:10:57'),(123,14,'interruptor',3,'2026-05-28 23:10:57'),(124,14,'contactor',3,'2026-05-28 23:10:57'),(125,14,'arrancador',3,'2026-05-28 23:10:57'),(126,14,'voltaje',2,'2026-05-28 23:10:57'),(127,14,'amperaje',2,'2026-05-28 23:10:57'),(128,14,'corriente',2,'2026-05-28 23:10:57'),(129,14,'panel',2,'2026-05-28 23:10:57'),(130,14,'tablero',2,'2026-05-28 23:10:57'),(131,14,'cable',1,'2026-05-28 23:10:57'),(132,14,'sin energia',3,'2026-05-28 23:10:57'),(133,14,'no enciende',2,'2026-05-28 23:10:57'),(134,14,'transformador',3,'2026-05-28 23:10:57'),(135,14,'subestacion',3,'2026-05-28 23:10:57'),(136,14,'tierra fisica',3,'2026-05-28 23:10:57'),(137,14,'relevador',3,'2026-05-28 23:10:57'),(138,14,'variador',3,'2026-05-28 23:10:57'),(151,15,'plc',3,'2026-05-28 23:10:57'),(152,15,'sensor',3,'2026-05-28 23:10:57'),(153,15,'hmi',3,'2026-05-28 23:10:57'),(154,15,'pantalla tactil',3,'2026-05-28 23:10:57'),(155,15,'tarjeta',2,'2026-05-28 23:10:57'),(156,15,'modulo',2,'2026-05-28 23:10:57'),(157,15,'programacion',2,'2026-05-28 23:10:57'),(158,15,'logica',2,'2026-05-28 23:10:57'),(159,15,'fotocelda',3,'2026-05-28 23:10:57'),(160,15,'encoder',3,'2026-05-28 23:10:57'),(166,16,'fuga',3,'2026-05-28 23:10:57'),(167,16,'aceite',2,'2026-05-28 23:10:57'),(168,16,'manguera',2,'2026-05-28 23:10:57'),(169,16,'cilindro',3,'2026-05-28 23:10:57'),(170,16,'bomba hidraulica',3,'2026-05-28 23:10:57'),(171,16,'valvula',2,'2026-05-28 23:10:57'),(172,16,'piston',3,'2026-05-28 23:10:57'),(173,16,'sin presion',3,'2026-05-28 23:10:57'),(174,16,'manometro',2,'2026-05-28 23:10:57'),(175,16,'sello hidraulico',3,'2026-05-28 23:10:57'),(181,17,'aire comprimido',3,'2026-05-28 23:10:57'),(182,17,'compresor de aire',3,'2026-05-28 23:10:57'),(183,17,'electrovalvula',3,'2026-05-28 23:10:57'),(184,17,'piston neumatico',3,'2026-05-28 23:10:57'),(185,17,'manguera neumatica',2,'2026-05-28 23:10:57'),(186,17,'fuga de aire',3,'2026-05-28 23:10:57'),(187,17,'pistola',2,'2026-05-28 23:10:57'),(188,17,'sin aire',3,'2026-05-28 23:10:57'),(196,18,'camara fria',3,'2026-05-28 23:10:57'),(197,18,'camara frigorifica',3,'2026-05-28 23:10:57'),(198,18,'refrigerador',3,'2026-05-28 23:10:57'),(199,18,'congelador',3,'2026-05-28 23:10:57'),(200,18,'compresor de refrigeracion',3,'2026-05-28 23:10:57'),(201,18,'condensador',3,'2026-05-28 23:10:57'),(202,18,'evaporador',3,'2026-05-28 23:10:57'),(203,18,'gas refrigerante',3,'2026-05-28 23:10:57'),(204,18,'no enfria',3,'2026-05-28 23:10:57'),(205,18,'temperatura alta',3,'2026-05-28 23:10:57'),(206,18,'descongelar',2,'2026-05-28 23:10:57'),(207,18,'expansion',2,'2026-05-28 23:10:57'),(208,18,'r404',3,'2026-05-28 23:10:57'),(209,18,'r134',3,'2026-05-28 23:10:57'),(210,18,'amoniaco',3,'2026-05-28 23:10:57'),(211,19,'caldera',3,'2026-05-28 23:10:57'),(212,19,'vapor',3,'2026-05-28 23:10:57'),(213,19,'quemador',3,'2026-05-28 23:10:57'),(214,19,'trampa de vapor',3,'2026-05-28 23:10:57'),(215,19,'tubo de caldera',3,'2026-05-28 23:10:57'),(216,19,'condensado',2,'2026-05-28 23:10:57'),(217,19,'agua de alimentacion',2,'2026-05-28 23:10:57'),(218,20,'soldar',3,'2026-05-28 23:10:57'),(219,20,'soldadura',3,'2026-05-28 23:10:57'),(220,20,'electrodo',3,'2026-05-28 23:10:57'),(221,20,'mig',3,'2026-05-28 23:10:57'),(222,20,'tig',3,'2026-05-28 23:10:57'),(223,20,'inox',2,'2026-05-28 23:10:57'),(224,20,'cordon',2,'2026-05-28 23:10:57'),(225,21,'lubricar',3,'2026-05-28 23:10:57'),(226,21,'engrasar',3,'2026-05-28 23:10:57'),(227,21,'grasa',2,'2026-05-28 23:10:57'),(228,21,'graseras',3,'2026-05-28 23:10:57'),(229,21,'rutina de lubricacion',3,'2026-05-28 23:10:57'),(232,25,'calibrar',3,'2026-05-28 23:10:57'),(233,25,'calibracion',3,'2026-05-28 23:10:57'),(234,25,'medidor',3,'2026-05-28 23:10:57'),(235,25,'transductor',3,'2026-05-28 23:10:57'),(236,25,'termopar',3,'2026-05-28 23:10:57'),(237,25,'rtd',3,'2026-05-28 23:10:57'),(238,25,'transmisor',3,'2026-05-28 23:10:57'),(239,25,'controlador',2,'2026-05-28 23:10:57'),(247,26,'osmosis',3,'2026-05-28 23:10:57'),(248,26,'suavizador',3,'2026-05-28 23:10:57'),(249,26,'filtro de agua',3,'2026-05-28 23:10:57'),(250,26,'bomba de agua',3,'2026-05-28 23:10:57'),(251,26,'tinaco',2,'2026-05-28 23:10:57'),(252,26,'cisterna',2,'2026-05-28 23:10:57'),(254,24,'extintor',3,'2026-05-28 23:10:57'),(255,24,'epp',3,'2026-05-28 23:10:57'),(256,24,'guarda',3,'2026-05-28 23:10:57'),(257,24,'paro de emergencia',3,'2026-05-28 23:10:57'),(258,24,'señalizacion',2,'2026-05-28 23:10:57'),(259,24,'loto',3,'2026-05-28 23:10:57'),(260,24,'bloqueo etiquetado',3,'2026-05-28 23:10:57'),(261,22,'limpieza profunda',3,'2026-05-28 23:10:57'),(262,22,'sanitizar',3,'2026-05-28 23:10:57'),(263,22,'cip',3,'2026-05-28 23:10:57'),(264,22,'sip',3,'2026-05-28 23:10:57'),(265,22,'lavado',2,'2026-05-28 23:10:57');
/*!40000 ALTER TABLE `categorias_palabras_clave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comentario_reacciones`
--

DROP TABLE IF EXISTS `comentario_reacciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comentario_reacciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comentario_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `emoji` varchar(10) NOT NULL COMMENT 'Emoji unicode',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_react` (`comentario_id`,`usuario_id`,`emoji`),
  KEY `idx_comentario` (`comentario_id`),
  KEY `fk_react_usuario` (`usuario_id`),
  CONSTRAINT `fk_react_comentario` FOREIGN KEY (`comentario_id`) REFERENCES `incidencias_comentarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_react_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comentario_reacciones`
--

LOCK TABLES `comentario_reacciones` WRITE;
/*!40000 ALTER TABLE `comentario_reacciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `comentario_reacciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipo_componentes`
--

DROP TABLE IF EXISTS `equipo_componentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipo_componentes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `equipo_id` int(11) NOT NULL,
  `nombre` varchar(150) NOT NULL COMMENT 'ej. Motor eléctrico, Banda B-50, Filtro de aceite',
  `tipo` varchar(80) DEFAULT NULL COMMENT 'ej. Motor, Sensor, Filtro, Banda',
  `marca` varchar(100) DEFAULT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `numero_parte` varchar(100) DEFAULT NULL COMMENT 'Part number del fabricante',
  `numero_serie` varchar(100) DEFAULT NULL,
  `fecha_instalacion` date DEFAULT NULL,
  `vida_util_meses` int(11) DEFAULT NULL COMMENT 'Vida útil estimada en meses',
  `proxima_revision` date DEFAULT NULL,
  `costo_unitario` decimal(10,2) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `estado` enum('operando','desgaste','falla','reemplazado','retirado') NOT NULL DEFAULT 'operando',
  `criticidad` enum('baja','media','alta','critica') NOT NULL DEFAULT 'media' COMMENT 'Impacto de su falla en el equipo padre',
  `posicion` varchar(100) DEFAULT NULL COMMENT 'Ubicación física dentro del equipo (ej. lado izquierdo, etapa 2)',
  `notas` text DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_por_id` int(11) DEFAULT NULL,
  `actualizado_por_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_equipo` (`equipo_id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_proxima_revision` (`proxima_revision`),
  KEY `fk_comp_proveedor` (`proveedor_id`),
  KEY `fk_comp_creador` (`creado_por_id`),
  KEY `fk_comp_actualizador` (`actualizado_por_id`),
  CONSTRAINT `fk_comp_actualizador` FOREIGN KEY (`actualizado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_comp_creador` FOREIGN KEY (`creado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_comp_equipo` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_comp_proveedor` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo_componentes`
--

LOCK TABLES `equipo_componentes` WRITE;
/*!40000 ALTER TABLE `equipo_componentes` DISABLE KEYS */;
INSERT INTO `equipo_componentes` VALUES (1,1,'motor','prueba','gdo','1200','skf1','000000','2026-05-06',80,'2026-05-29',100.00,NULL,'operando','media','arriba','prueba',1,1,1,'2026-05-29 04:50:20','2026-05-29 04:50:20');
/*!40000 ALTER TABLE `equipo_componentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipo_componentes_historial`
--

DROP TABLE IF EXISTS `equipo_componentes_historial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipo_componentes_historial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `componente_id` int(11) NOT NULL,
  `accion` enum('instalado','reemplazado','reparado','retirado','revisado') NOT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `incidencia_id` int(11) DEFAULT NULL COMMENT 'Si el cambio fue por una incidencia/orden',
  `usuario_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_componente` (`componente_id`,`creado_en`),
  KEY `idx_incidencia` (`incidencia_id`),
  KEY `fk_comp_hist_usuario` (`usuario_id`),
  CONSTRAINT `fk_comp_hist_comp` FOREIGN KEY (`componente_id`) REFERENCES `equipo_componentes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_comp_hist_inc` FOREIGN KEY (`incidencia_id`) REFERENCES `incidencias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_comp_hist_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo_componentes_historial`
--

LOCK TABLES `equipo_componentes_historial` WRITE;
/*!40000 ALTER TABLE `equipo_componentes_historial` DISABLE KEYS */;
INSERT INTO `equipo_componentes_historial` VALUES (1,1,'instalado','Componente registrado: motor',NULL,1,'2026-05-29 04:50:20');
/*!40000 ALTER TABLE `equipo_componentes_historial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipo_fotos`
--

DROP TABLE IF EXISTS `equipo_fotos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipo_fotos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `equipo_id` int(11) NOT NULL,
  `ruta` varchar(255) NOT NULL COMMENT 'Ruta relativa (assets/equipos/...)',
  `descripcion` varchar(255) DEFAULT NULL,
  `es_portada` tinyint(1) NOT NULL DEFAULT 0,
  `subido_por_id` int(11) DEFAULT NULL,
  `tamano_bytes` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_equipo` (`equipo_id`),
  KEY `fk_foto_usuario` (`subido_por_id`),
  CONSTRAINT `fk_foto_equipo` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_foto_usuario` FOREIGN KEY (`subido_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo_fotos`
--

LOCK TABLES `equipo_fotos` WRITE;
/*!40000 ALTER TABLE `equipo_fotos` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipo_fotos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipo_transferencias`
--

DROP TABLE IF EXISTS `equipo_transferencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipo_transferencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `equipo_id` int(11) NOT NULL,
  `sucursal_origen_id` int(11) DEFAULT NULL COMMENT 'Null si era equipo nuevo recien llegado',
  `sucursal_destino_id` int(11) NOT NULL,
  `area_origen_id` int(11) DEFAULT NULL,
  `area_destino_id` int(11) DEFAULT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `fecha_transferencia` date NOT NULL,
  `realizado_por_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_equipo` (`equipo_id`),
  KEY `idx_fecha` (`fecha_transferencia`),
  KEY `fk_trans_origen` (`sucursal_origen_id`),
  KEY `fk_trans_destino` (`sucursal_destino_id`),
  KEY `fk_trans_area_origen` (`area_origen_id`),
  KEY `fk_trans_area_destino` (`area_destino_id`),
  KEY `fk_trans_usuario` (`realizado_por_id`),
  CONSTRAINT `fk_trans_area_destino` FOREIGN KEY (`area_destino_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_trans_area_origen` FOREIGN KEY (`area_origen_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_trans_destino` FOREIGN KEY (`sucursal_destino_id`) REFERENCES `sucursales` (`id`),
  CONSTRAINT `fk_trans_equipo` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_trans_origen` FOREIGN KEY (`sucursal_origen_id`) REFERENCES `sucursales` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_trans_usuario` FOREIGN KEY (`realizado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo_transferencias`
--

LOCK TABLES `equipo_transferencias` WRITE;
/*!40000 ALTER TABLE `equipo_transferencias` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipo_transferencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipos`
--

DROP TABLE IF EXISTS `equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_inventario` varchar(50) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `marca` varchar(100) DEFAULT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `numero_serie` varchar(100) DEFAULT NULL,
  `sucursal_id` int(11) NOT NULL,
  `planta_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `fecha_compra` date DEFAULT NULL,
  `costo_compra` decimal(12,2) DEFAULT NULL,
  `vida_util_meses` int(11) DEFAULT NULL COMMENT 'Vida util estimada en meses (60 = 5 años)',
  `fecha_baja` date DEFAULT NULL,
  `motivo_baja` varchar(255) DEFAULT NULL,
  `ubicacion` varchar(255) DEFAULT NULL,
  `responsable_id` int(11) DEFAULT NULL,
  `fecha_adquisicion` date DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `estado_vida` enum('nuevo','en_uso','en_reparacion','dado_de_baja') NOT NULL DEFAULT 'en_uso',
  `creado_en` datetime DEFAULT current_timestamp(),
  `actualizado_en` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `pos_x` decimal(5,2) DEFAULT NULL COMMENT '% desde el borde izquierdo',
  `pos_y` decimal(5,2) DEFAULT NULL COMMENT '% desde el borde superior',
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_inventario` (`codigo_inventario`),
  KEY `area_id` (`area_id`),
  KEY `responsable_id` (`responsable_id`),
  KEY `idx_sucursal_area` (`sucursal_id`,`area_id`),
  KEY `idx_tipo` (`tipo`),
  KEY `fk_equipo_proveedor` (`proveedor_id`),
  KEY `idx_pos` (`pos_x`,`pos_y`),
  KEY `fk_equipo_planta` (`planta_id`),
  CONSTRAINT `equipos_ibfk_1` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`),
  CONSTRAINT `equipos_ibfk_2` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `equipos_ibfk_3` FOREIGN KEY (`responsable_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_equipo_planta` FOREIGN KEY (`planta_id`) REFERENCES `sucursal_plantas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_equipo_proveedor` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipos`
--

LOCK TABLES `equipos` WRITE;
/*!40000 ALTER TABLE `equipos` DISABLE KEYS */;
INSERT INTO `equipos` VALUES (1,'BAC-001','EQUIPO DE PRUEBAS','Prueba','GDO','nuevo',NULL,1,NULL,32,NULL,'2026-05-28',10.00,120,NULL,NULL,'Aqui',NULL,NULL,NULL,1,'en_uso','2026-05-28 21:38:43','2026-05-28 21:38:43',NULL,NULL);
/*!40000 ALTER TABLE `equipos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estados`
--

DROP TABLE IF EXISTS `estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `orden` int(11) NOT NULL,
  `color` varchar(20) NOT NULL DEFAULT '#6B7280',
  `es_inicial` tinyint(1) NOT NULL DEFAULT 0,
  `es_final` tinyint(1) NOT NULL DEFAULT 0,
  `descripcion` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estados`
--

LOCK TABLES `estados` WRITE;
/*!40000 ALTER TABLE `estados` DISABLE KEYS */;
INSERT INTO `estados` VALUES (1,'Abierta',1,'#DC2626',1,0,'Recién registrada, sin atender',1),(2,'Asignada',2,'#EA580C',0,0,'Asignada a un técnico',1),(3,'En proceso',3,'#D97706',0,0,'Siendo atendida activamente',1),(4,'En espera de refacción',4,'#8B5CF6',0,0,'Esperando pieza para continuar',1),(5,'En espera',5,'#6B7280',0,0,'Esperando información o terceros',1),(6,'Resuelta',6,'#0EA5E9',0,0,'Solucionada, pendiente de confirmación',1),(7,'Completada',7,'#16A34A',0,1,'Confirmada y cerrada',1),(8,'Cancelada',8,'#6B7280',0,1,'Anulada sin resolución',1);
/*!40000 ALTER TABLE `estados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `herramientas`
--

DROP TABLE IF EXISTS `herramientas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `herramientas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) NOT NULL COMMENT 'Código interno único, ej. HER-001',
  `nombre` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `tipo` varchar(80) DEFAULT NULL COMMENT 'Eléctrica, manual, medición, etc.',
  `marca` varchar(100) DEFAULT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `numero_serie` varchar(100) DEFAULT NULL,
  `sucursal_id` int(11) NOT NULL COMMENT 'Sucursal donde se almacena',
  `ubicacion` varchar(150) DEFAULT NULL COMMENT 'ej. Taller, Anaquel B-2',
  `estado` enum('disponible','prestada','en_reparacion','extraviada','baja') NOT NULL DEFAULT 'disponible',
  `prestamo_activo_id` int(11) DEFAULT NULL COMMENT 'ID del préstamo activo si está prestada',
  `fecha_adquisicion` date DEFAULT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `foto_url` varchar(255) DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_por_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_codigo` (`codigo`),
  KEY `idx_estado` (`estado`),
  KEY `idx_sucursal` (`sucursal_id`),
  KEY `idx_tipo` (`tipo`),
  KEY `fk_her_proveedor` (`proveedor_id`),
  KEY `fk_her_creador` (`creado_por_id`),
  KEY `fk_her_prestamo_activo` (`prestamo_activo_id`),
  CONSTRAINT `fk_her_creador` FOREIGN KEY (`creado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_her_prestamo_activo` FOREIGN KEY (`prestamo_activo_id`) REFERENCES `herramientas_prestamos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_her_proveedor` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_her_sucursal` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `herramientas`
--

LOCK TABLES `herramientas` WRITE;
/*!40000 ALTER TABLE `herramientas` DISABLE KEYS */;
INSERT INTO `herramientas` VALUES (1,'HER-001','Martillo de prueba','para pruebas','Manual','GDO','SI','00001',1,'Oficina','disponible',NULL,'2026-05-28',10.00,NULL,NULL,'PRUEBA',1,1,'2026-05-29 17:51:04','2026-05-29 17:53:43');
/*!40000 ALTER TABLE `herramientas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `herramientas_prestamos`
--

DROP TABLE IF EXISTS `herramientas_prestamos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `herramientas_prestamos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `herramienta_id` int(11) NOT NULL,
  `prestada_a_id` int(11) NOT NULL COMMENT 'Usuario al que se le prestó',
  `autorizada_por_id` int(11) NOT NULL COMMENT 'Quien autorizó el préstamo',
  `fecha_salida` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_devolucion_esperada` date DEFAULT NULL,
  `fecha_devolucion_real` timestamp NULL DEFAULT NULL,
  `recibida_por_id` int(11) DEFAULT NULL COMMENT 'Quien recibe la devolución',
  `motivo` varchar(255) DEFAULT NULL COMMENT 'Para qué se necesita',
  `incidencia_id` int(11) DEFAULT NULL COMMENT 'Si se presta para una orden específica',
  `estado` enum('activo','devuelta','devuelta_con_dano','extraviada') NOT NULL DEFAULT 'activo',
  `condicion_devolucion` enum('buena','dañada','extraviada','reparada') DEFAULT NULL,
  `notas_salida` text DEFAULT NULL,
  `notas_devolucion` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_herramienta` (`herramienta_id`,`fecha_salida`),
  KEY `idx_usuario` (`prestada_a_id`,`estado`),
  KEY `idx_estado_fecha` (`estado`,`fecha_devolucion_esperada`),
  KEY `idx_incidencia` (`incidencia_id`),
  KEY `fk_pres_autoriza` (`autorizada_por_id`),
  KEY `fk_pres_recibe` (`recibida_por_id`),
  CONSTRAINT `fk_pres_autoriza` FOREIGN KEY (`autorizada_por_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `fk_pres_herramienta` FOREIGN KEY (`herramienta_id`) REFERENCES `herramientas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pres_incidencia` FOREIGN KEY (`incidencia_id`) REFERENCES `incidencias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pres_recibe` FOREIGN KEY (`recibida_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pres_usuario` FOREIGN KEY (`prestada_a_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `herramientas_prestamos`
--

LOCK TABLES `herramientas_prestamos` WRITE;
/*!40000 ALTER TABLE `herramientas_prestamos` DISABLE KEYS */;
INSERT INTO `herramientas_prestamos` VALUES (1,1,17,1,'2026-05-29 17:53:19','2026-05-30','2026-05-29 17:53:43',1,'PRUEBA',NULL,'devuelta','buena','SE PROBARA','prueba exitosa');
/*!40000 ALTER TABLE `herramientas_prestamos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importaciones`
--

DROP TABLE IF EXISTS `importaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` enum('usuarios','equipos','incidencias') NOT NULL,
  `nombre_archivo` varchar(255) NOT NULL,
  `total_filas` int(11) NOT NULL DEFAULT 0,
  `exitosos` int(11) NOT NULL DEFAULT 0,
  `fallidos` int(11) NOT NULL DEFAULT 0,
  `errores_json` text DEFAULT NULL COMMENT 'JSON con detalles de errores por fila',
  `realizado_por_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tipo` (`tipo`),
  KEY `idx_fecha` (`creado_en`),
  KEY `fk_import_usuario` (`realizado_por_id`),
  CONSTRAINT `fk_import_usuario` FOREIGN KEY (`realizado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importaciones`
--

LOCK TABLES `importaciones` WRITE;
/*!40000 ALTER TABLE `importaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `importaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidencia_refacciones`
--

DROP TABLE IF EXISTS `incidencia_refacciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incidencia_refacciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `incidencia_id` int(11) NOT NULL,
  `refaccion_id` int(11) NOT NULL,
  `cantidad` decimal(10,2) NOT NULL,
  `costo_unitario` decimal(10,2) DEFAULT NULL COMMENT 'Costo al momento de usar',
  `costo_total` decimal(12,2) DEFAULT NULL COMMENT 'cantidad * costo_unitario',
  `movimiento_id` int(11) DEFAULT NULL COMMENT 'ID del movimiento de salida generado',
  `componente_id` int(11) DEFAULT NULL COMMENT 'Si reemplazó un componente específico',
  `notas` varchar(500) DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_incidencia` (`incidencia_id`),
  KEY `idx_refaccion` (`refaccion_id`),
  KEY `idx_componente` (`componente_id`),
  KEY `fk_incref_movimiento` (`movimiento_id`),
  KEY `fk_incref_usuario` (`usuario_id`),
  CONSTRAINT `fk_incref_componente` FOREIGN KEY (`componente_id`) REFERENCES `equipo_componentes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_incref_incidencia` FOREIGN KEY (`incidencia_id`) REFERENCES `incidencias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_incref_movimiento` FOREIGN KEY (`movimiento_id`) REFERENCES `refacciones_movimientos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_incref_refaccion` FOREIGN KEY (`refaccion_id`) REFERENCES `refacciones` (`id`),
  CONSTRAINT `fk_incref_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidencia_refacciones`
--

LOCK TABLES `incidencia_refacciones` WRITE;
/*!40000 ALTER TABLE `incidencia_refacciones` DISABLE KEYS */;
INSERT INTO `incidencia_refacciones` VALUES (1,37,1,1.00,10.00,10.00,4,1,'prueba',1,'2026-05-29 04:52:52');
/*!40000 ALTER TABLE `incidencia_refacciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidencias`
--

DROP TABLE IF EXISTS `incidencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incidencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `folio` varchar(30) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descripcion` text NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `subcategoria_id` int(11) DEFAULT NULL,
  `tipo_trabajo_id` int(11) DEFAULT NULL,
  `severidad_id` int(11) NOT NULL,
  `estado_id` int(11) NOT NULL,
  `origen_reporte_id` int(11) DEFAULT NULL,
  `equipo_id` int(11) DEFAULT NULL,
  `reportado_por_id` int(11) NOT NULL,
  `reportante_nombre` varchar(150) DEFAULT NULL,
  `reportante_puesto` varchar(100) DEFAULT NULL,
  `asignado_a_id` int(11) DEFAULT NULL,
  `proveedor_escalado_id` int(11) DEFAULT NULL,
  `resuelto_por_id` int(11) DEFAULT NULL,
  `causa_raiz` text DEFAULT NULL,
  `solucion` text DEFAULT NULL,
  `recomendaciones` text DEFAULT NULL,
  `acciones_preventivas` text DEFAULT NULL,
  `es_reincidencia` tinyint(1) NOT NULL DEFAULT 0,
  `incidencia_padre_id` int(11) DEFAULT NULL,
  `veces_recurrida` int(11) NOT NULL DEFAULT 0,
  `fecha_evento` datetime NOT NULL,
  `fecha_atencion` datetime DEFAULT NULL,
  `fecha_resolucion` datetime DEFAULT NULL,
  `fecha_cierre` datetime DEFAULT NULL,
  `tiempo_respuesta_min` int(11) DEFAULT NULL,
  `tiempo_resolucion_min` int(11) DEFAULT NULL,
  `sla_cumplido` tinyint(1) DEFAULT NULL,
  `fecha_limite_sla` datetime DEFAULT NULL,
  `confirmado_por_reportante` tinyint(1) DEFAULT 0,
  `fecha_confirmacion` datetime DEFAULT NULL,
  `calificacion_servicio` int(11) DEFAULT NULL,
  `comentario_reportante` text DEFAULT NULL,
  `creado_en` datetime DEFAULT current_timestamp(),
  `creado_por_id` int(11) NOT NULL,
  `actualizado_en` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `actualizado_por_id` int(11) DEFAULT NULL,
  `archivada` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 si está archivada (resuelta hace >1 año)',
  `fecha_archivado` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `folio` (`folio`),
  KEY `categoria_id` (`categoria_id`),
  KEY `subcategoria_id` (`subcategoria_id`),
  KEY `tipo_trabajo_id` (`tipo_trabajo_id`),
  KEY `estado_id` (`estado_id`),
  KEY `origen_reporte_id` (`origen_reporte_id`),
  KEY `resuelto_por_id` (`resuelto_por_id`),
  KEY `incidencia_padre_id` (`incidencia_padre_id`),
  KEY `creado_por_id` (`creado_por_id`),
  KEY `actualizado_por_id` (`actualizado_por_id`),
  KEY `idx_folio` (`folio`),
  KEY `idx_sucursal_estado` (`sucursal_id`,`estado_id`),
  KEY `idx_area` (`area_id`),
  KEY `idx_severidad` (`severidad_id`),
  KEY `idx_asignado` (`asignado_a_id`),
  KEY `idx_reportado_por` (`reportado_por_id`),
  KEY `idx_equipo` (`equipo_id`),
  KEY `idx_fecha_evento` (`fecha_evento`),
  KEY `idx_reincidencia` (`es_reincidencia`,`incidencia_padre_id`),
  KEY `idx_busqueda_reincidencia` (`equipo_id`,`categoria_id`,`fecha_evento`),
  KEY `fk_incidencia_proveedor` (`proveedor_escalado_id`),
  KEY `idx_archivada` (`archivada`),
  CONSTRAINT `fk_incidencia_proveedor` FOREIGN KEY (`proveedor_escalado_id`) REFERENCES `proveedores` (`id`) ON DELETE SET NULL,
  CONSTRAINT `incidencias_ibfk_1` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`),
  CONSTRAINT `incidencias_ibfk_10` FOREIGN KEY (`reportado_por_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `incidencias_ibfk_11` FOREIGN KEY (`asignado_a_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `incidencias_ibfk_12` FOREIGN KEY (`resuelto_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `incidencias_ibfk_13` FOREIGN KEY (`incidencia_padre_id`) REFERENCES `incidencias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `incidencias_ibfk_14` FOREIGN KEY (`creado_por_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `incidencias_ibfk_15` FOREIGN KEY (`actualizado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `incidencias_ibfk_2` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`),
  CONSTRAINT `incidencias_ibfk_3` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `incidencias_ibfk_4` FOREIGN KEY (`subcategoria_id`) REFERENCES `subcategorias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `incidencias_ibfk_5` FOREIGN KEY (`tipo_trabajo_id`) REFERENCES `tipos_trabajo` (`id`) ON DELETE SET NULL,
  CONSTRAINT `incidencias_ibfk_6` FOREIGN KEY (`severidad_id`) REFERENCES `severidades` (`id`),
  CONSTRAINT `incidencias_ibfk_7` FOREIGN KEY (`estado_id`) REFERENCES `estados` (`id`),
  CONSTRAINT `incidencias_ibfk_8` FOREIGN KEY (`origen_reporte_id`) REFERENCES `origenes_reporte` (`id`) ON DELETE SET NULL,
  CONSTRAINT `incidencias_ibfk_9` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidencias`
--

LOCK TABLES `incidencias` WRITE;
/*!40000 ALTER TABLE `incidencias` DISABLE KEYS */;
INSERT INTO `incidencias` VALUES (37,'INC-BAC-2026-0001','Falla Inicial prueba del sistema','falla de prueba',1,32,19,NULL,20,4,7,12,1,1,'Luis Roodriguez','Jefe de Sistemas',1,NULL,1,NULL,NULL,NULL,NULL,0,NULL,0,'2026-05-28 21:38:00','2026-05-28 21:53:18','2026-05-28 21:53:22','2026-05-28 21:53:22',15,0,1,'2026-05-31 21:38:00',0,NULL,NULL,NULL,'2026-05-28 21:39:36',1,'2026-05-28 21:53:22',1,0,NULL),(38,'INC-BAC-2026-0002','Cambio de boliler','Supervisor JAMG reporto que uno de los boilers de agua caliente estaba tirando agua',1,37,16,NULL,15,2,1,13,NULL,1,'JAMG','Supervisor',17,NULL,NULL,'El boiler fallo por antiguedad y por duraze del agua del edificio, causando que el tanque de agua se carcomiera.','se compro un boiler nuevo y la instalacion la iso el plomero fulano.','Mantener agua suabe y remplazar boiler al terminar su periodo de garantia.',NULL,0,NULL,0,'2026-06-01 14:25:00','2026-06-01 14:29:36',NULL,NULL,5,NULL,NULL,'2026-06-01 22:25:00',0,NULL,NULL,NULL,'2026-06-01 14:29:36',1,'2026-06-01 14:29:36',NULL,0,NULL);
/*!40000 ALTER TABLE `incidencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidencias_adjuntos`
--

DROP TABLE IF EXISTS `incidencias_adjuntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incidencias_adjuntos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `incidencia_id` int(11) NOT NULL,
  `nombre_original` varchar(255) NOT NULL,
  `nombre_archivo` varchar(255) NOT NULL,
  `ruta` varchar(500) NOT NULL,
  `tipo_mime` varchar(100) DEFAULT NULL,
  `tamano_bytes` int(11) DEFAULT NULL,
  `momento` varchar(20) DEFAULT 'durante',
  `descripcion` varchar(255) DEFAULT NULL,
  `subido_por_id` int(11) NOT NULL,
  `subido_en` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `subido_por_id` (`subido_por_id`),
  KEY `idx_incidencia` (`incidencia_id`),
  CONSTRAINT `incidencias_adjuntos_ibfk_1` FOREIGN KEY (`incidencia_id`) REFERENCES `incidencias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `incidencias_adjuntos_ibfk_2` FOREIGN KEY (`subido_por_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidencias_adjuntos`
--

LOCK TABLES `incidencias_adjuntos` WRITE;
/*!40000 ALTER TABLE `incidencias_adjuntos` DISABLE KEYS */;
/*!40000 ALTER TABLE `incidencias_adjuntos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidencias_comentarios`
--

DROP TABLE IF EXISTS `incidencias_comentarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incidencias_comentarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `incidencia_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `comentario` text NOT NULL,
  `es_interno` tinyint(1) NOT NULL DEFAULT 0,
  `creado_en` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_incidencia` (`incidencia_id`),
  CONSTRAINT `incidencias_comentarios_ibfk_1` FOREIGN KEY (`incidencia_id`) REFERENCES `incidencias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `incidencias_comentarios_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidencias_comentarios`
--

LOCK TABLES `incidencias_comentarios` WRITE;
/*!40000 ALTER TABLE `incidencias_comentarios` DISABLE KEYS */;
INSERT INTO `incidencias_comentarios` VALUES (1,38,1,'@julian por favor empezar a utilizar esta plataforma para registrar todos los trabajos de mantenimiento industrial',0,'2026-06-01 14:30:45');
/*!40000 ALTER TABLE `incidencias_comentarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidencias_etiquetas`
--

DROP TABLE IF EXISTS `incidencias_etiquetas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incidencias_etiquetas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `incidencia_id` int(11) NOT NULL,
  `etiqueta` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_incidencia_etiqueta` (`incidencia_id`,`etiqueta`),
  KEY `idx_etiqueta` (`etiqueta`),
  CONSTRAINT `incidencias_etiquetas_ibfk_1` FOREIGN KEY (`incidencia_id`) REFERENCES `incidencias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidencias_etiquetas`
--

LOCK TABLES `incidencias_etiquetas` WRITE;
/*!40000 ALTER TABLE `incidencias_etiquetas` DISABLE KEYS */;
/*!40000 ALTER TABLE `incidencias_etiquetas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidencias_historial`
--

DROP TABLE IF EXISTS `incidencias_historial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incidencias_historial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `incidencia_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `accion` varchar(50) NOT NULL,
  `campo` varchar(100) DEFAULT NULL,
  `valor_anterior` text DEFAULT NULL,
  `valor_nuevo` text DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `creado_en` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_incidencia` (`incidencia_id`),
  KEY `idx_fecha` (`creado_en`),
  CONSTRAINT `incidencias_historial_ibfk_1` FOREIGN KEY (`incidencia_id`) REFERENCES `incidencias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `incidencias_historial_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidencias_historial`
--

LOCK TABLES `incidencias_historial` WRITE;
/*!40000 ALTER TABLE `incidencias_historial` DISABLE KEYS */;
INSERT INTO `incidencias_historial` VALUES (10,37,1,'creada',NULL,NULL,'INC-BAC-2026-0001','Incidencia creada con folio INC-BAC-2026-0001','2026-05-28 21:39:36'),(11,37,1,'asignado','asignado_a_id','','','Asignado a sin asignar','2026-05-28 21:53:08'),(12,37,1,'asignado','asignado_a_id','','1','Asignado a Administrador del Sistema','2026-05-28 21:53:18'),(13,37,1,'estado_cambiado','estado_id','1','7','Estado cambiado a Completada','2026-05-28 21:53:22'),(14,38,1,'creada',NULL,NULL,'INC-BAC-2026-0002','Incidencia creada con folio INC-BAC-2026-0002','2026-06-01 14:29:36');
/*!40000 ALTER TABLE `incidencias_historial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mantenimientos`
--

DROP TABLE IF EXISTS `mantenimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `equipo_id` int(11) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha_programada` date NOT NULL,
  `hora_programada` time DEFAULT NULL,
  `asignado_a_id` int(11) DEFAULT NULL COMMENT 'Tecnico asignado',
  `proveedor_id` int(11) DEFAULT NULL COMMENT 'Si lo hace un proveedor externo',
  `estado` enum('programado','proximo','en_progreso','completado','cancelado','vencido') NOT NULL DEFAULT 'programado',
  `es_recurrente` tinyint(1) NOT NULL DEFAULT 0,
  `recurrencia_tipo` enum('dias','semanas','meses','anios') DEFAULT NULL,
  `recurrencia_valor` int(11) DEFAULT NULL COMMENT 'Cada cuantas unidades (ej. 3 meses)',
  `mantenimiento_padre_id` int(11) DEFAULT NULL COMMENT 'Si fue auto-generado, apunta al original',
  `fecha_inicio_real` datetime DEFAULT NULL,
  `fecha_completado` datetime DEFAULT NULL,
  `realizado_por_id` int(11) DEFAULT NULL COMMENT 'Quien lo ejecuto realmente',
  `resultado` text DEFAULT NULL COMMENT 'Notas de lo que se hizo',
  `costo` decimal(10,2) DEFAULT NULL,
  `incidencia_generada_id` int(11) DEFAULT NULL COMMENT 'Si se convirtio en incidencia',
  `creado_por_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_equipo` (`equipo_id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha` (`fecha_programada`),
  KEY `idx_asignado` (`asignado_a_id`),
  KEY `idx_padre` (`mantenimiento_padre_id`),
  KEY `fk_mant_proveedor` (`proveedor_id`),
  KEY `fk_mant_realizado` (`realizado_por_id`),
  KEY `fk_mant_creador` (`creado_por_id`),
  KEY `fk_mant_incidencia` (`incidencia_generada_id`),
  CONSTRAINT `fk_mant_asignado` FOREIGN KEY (`asignado_a_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mant_creador` FOREIGN KEY (`creado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mant_equipo` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mant_incidencia` FOREIGN KEY (`incidencia_generada_id`) REFERENCES `incidencias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mant_padre` FOREIGN KEY (`mantenimiento_padre_id`) REFERENCES `mantenimientos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mant_proveedor` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mant_realizado` FOREIGN KEY (`realizado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mantenimientos`
--

LOCK TABLES `mantenimientos` WRITE;
/*!40000 ALTER TABLE `mantenimientos` DISABLE KEYS */;
/*!40000 ALTER TABLE `mantenimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificaciones`
--

DROP TABLE IF EXISTS `notificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notificaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `mensaje` text DEFAULT NULL,
  `enlace` varchar(500) DEFAULT NULL,
  `leida` tinyint(1) NOT NULL DEFAULT 0,
  `leida_en` datetime DEFAULT NULL,
  `creada_en` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_usuario_leida` (`usuario_id`,`leida`),
  KEY `idx_fecha` (`creada_en`),
  CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificaciones`
--

LOCK TABLES `notificaciones` WRITE;
/*!40000 ALTER TABLE `notificaciones` DISABLE KEYS */;
INSERT INTO `notificaciones` VALUES (3,17,'asignacion','Se te asignó INC-BAC-2026-0002','Cambio de boliler · Severidad: Alta','/UtilidadesBacal/BitacoraMantenimiento/incidencia_ver.php?id=38',0,NULL,'2026-06-01 14:29:36'),(4,17,'comentario','Nuevo comentario en INC-BAC-2026-0002','Administrador del Sistema: \"@julian por favor empezar a utilizar esta plataforma para registrar todos los trabajos de mantenimie…\"','/UtilidadesBacal/BitacoraMantenimiento/incidencia_ver.php?id=38',0,NULL,'2026-06-01 14:30:45');
/*!40000 ALTER TABLE `notificaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `origenes_reporte`
--

DROP TABLE IF EXISTS `origenes_reporte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `origenes_reporte` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `origenes_reporte`
--

LOCK TABLES `origenes_reporte` WRITE;
/*!40000 ALTER TABLE `origenes_reporte` DISABLE KEYS */;
INSERT INTO `origenes_reporte` VALUES (8,'Reporte de operador',1),(9,'Inspección de rutina',1),(10,'Mantenimiento programado',1),(11,'Falla detectada en línea',1),(12,'Auditoría',1),(13,'Solicitud de supervisor',1),(14,'Alarma de sistema',1),(15,'Otro',1);
/*!40000 ALTER TABLE `origenes_reporte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plantillas_incidencias`
--

DROP TABLE IF EXISTS `plantillas_incidencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plantillas_incidencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL COMMENT 'Para mostrar en la lista de plantillas',
  `icono` varchar(50) DEFAULT 'file-text' COMMENT 'Nombre del icono Lucide',
  `color` varchar(7) DEFAULT '#6B7280',
  `titulo` varchar(255) DEFAULT NULL,
  `descripcion_inc` text DEFAULT NULL COMMENT 'Descripcion del problema pre-rellenada',
  `area_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `subcategoria_id` int(11) DEFAULT NULL,
  `tipo_trabajo_id` int(11) DEFAULT NULL,
  `severidad_id` int(11) DEFAULT NULL,
  `origen_reporte_id` int(11) DEFAULT NULL,
  `solucion_sugerida` text DEFAULT NULL COMMENT 'Solucion tipica para este problema',
  `usos` int(11) NOT NULL DEFAULT 0 COMMENT 'Veces que se ha usado esta plantilla',
  `creado_por_id` int(11) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activo` (`activo`),
  KEY `idx_usos` (`usos`),
  KEY `fk_plantilla_area` (`area_id`),
  KEY `fk_plantilla_categoria` (`categoria_id`),
  KEY `fk_plantilla_subcategoria` (`subcategoria_id`),
  KEY `fk_plantilla_tipo` (`tipo_trabajo_id`),
  KEY `fk_plantilla_severidad` (`severidad_id`),
  KEY `fk_plantilla_origen` (`origen_reporte_id`),
  KEY `fk_plantilla_creador` (`creado_por_id`),
  CONSTRAINT `fk_plantilla_area` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_plantilla_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_plantilla_creador` FOREIGN KEY (`creado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_plantilla_origen` FOREIGN KEY (`origen_reporte_id`) REFERENCES `origenes_reporte` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_plantilla_severidad` FOREIGN KEY (`severidad_id`) REFERENCES `severidades` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_plantilla_subcategoria` FOREIGN KEY (`subcategoria_id`) REFERENCES `subcategorias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_plantilla_tipo` FOREIGN KEY (`tipo_trabajo_id`) REFERENCES `tipos_trabajo` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plantillas_incidencias`
--

LOCK TABLES `plantillas_incidencias` WRITE;
/*!40000 ALTER TABLE `plantillas_incidencias` DISABLE KEYS */;
/*!40000 ALTER TABLE `plantillas_incidencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor_contactos`
--

DROP TABLE IF EXISTS `proveedor_contactos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor_contactos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `nombre` varchar(150) NOT NULL COMMENT 'Nombre de la persona contacto',
  `puesto` varchar(100) DEFAULT NULL COMMENT 'ej. Asesor de basculas, Soporte',
  `telefono` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `notas` varchar(255) DEFAULT NULL COMMENT 'ej. Solo turno matutino',
  `es_principal` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Marca el contacto principal',
  `orden` int(11) NOT NULL DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_proveedor` (`proveedor_id`),
  CONSTRAINT `fk_contacto_proveedor` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor_contactos`
--

LOCK TABLES `proveedor_contactos` WRITE;
/*!40000 ALTER TABLE `proveedor_contactos` DISABLE KEYS */;
/*!40000 ALTER TABLE `proveedor_contactos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor_marcas`
--

DROP TABLE IF EXISTS `proveedor_marcas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor_marcas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `marca` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_proveedor_marca` (`proveedor_id`,`marca`),
  KEY `idx_proveedor` (`proveedor_id`),
  CONSTRAINT `fk_marca_proveedor` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor_marcas`
--

LOCK TABLES `proveedor_marcas` WRITE;
/*!40000 ALTER TABLE `proveedor_marcas` DISABLE KEYS */;
/*!40000 ALTER TABLE `proveedor_marcas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor_tipos_equipo`
--

DROP TABLE IF EXISTS `proveedor_tipos_equipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor_tipos_equipo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `tipo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_proveedor_tipo` (`proveedor_id`,`tipo`),
  KEY `idx_proveedor` (`proveedor_id`),
  CONSTRAINT `fk_tipo_proveedor` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor_tipos_equipo`
--

LOCK TABLES `proveedor_tipos_equipo` WRITE;
/*!40000 ALTER TABLE `proveedor_tipos_equipo` DISABLE KEYS */;
/*!40000 ALTER TABLE `proveedor_tipos_equipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL COMMENT 'Nombre comercial',
  `razon_social` varchar(200) DEFAULT NULL,
  `rfc` varchar(20) DEFAULT NULL,
  `servicio` varchar(255) DEFAULT NULL COMMENT 'Descripcion corta del servicio que ofrece',
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `sitio_web` varchar(200) DEFAULT NULL,
  `horario_atencion` varchar(255) DEFAULT NULL COMMENT 'ej. Lun-Vie 9-18hr',
  `calificacion` tinyint(3) unsigned DEFAULT NULL COMMENT '1-5 estrellas',
  `notas` text DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_por_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_nombre` (`nombre`),
  KEY `idx_activo` (`activo`),
  KEY `fk_proveedor_creador` (`creado_por_id`),
  CONSTRAINT `fk_proveedor_creador` FOREIGN KEY (`creado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recordatorios`
--

DROP TABLE IF EXISTS `recordatorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recordatorios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL COMMENT 'A quién se le envía',
  `titulo` varchar(200) NOT NULL,
  `mensaje` varchar(500) DEFAULT NULL,
  `fecha_envio` datetime NOT NULL COMMENT 'Cuándo enviar',
  `enlace` varchar(255) DEFAULT NULL,
  `entidad` varchar(50) DEFAULT NULL,
  `entidad_id` int(11) DEFAULT NULL,
  `enviado` tinyint(1) NOT NULL DEFAULT 0,
  `enviado_en` timestamp NULL DEFAULT NULL,
  `creado_por_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_enviar` (`enviado`,`fecha_envio`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `fk_rec_creador` (`creado_por_id`),
  CONSTRAINT `fk_rec_creador` FOREIGN KEY (`creado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rec_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recordatorios`
--

LOCK TABLES `recordatorios` WRITE;
/*!40000 ALTER TABLE `recordatorios` DISABLE KEYS */;
/*!40000 ALTER TABLE `recordatorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refacciones`
--

DROP TABLE IF EXISTS `refacciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refacciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) NOT NULL COMMENT 'Código interno único',
  `nombre` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `marca` varchar(100) DEFAULT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `numero_parte` varchar(100) DEFAULT NULL COMMENT 'Part number del fabricante',
  `categoria` varchar(80) DEFAULT NULL COMMENT 'Mecánica, Eléctrica, etc.',
  `unidad_medida` varchar(20) DEFAULT 'pieza' COMMENT 'pieza, metro, kg, litro',
  `costo_unitario` decimal(10,2) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `foto_url` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_por_id` int(11) DEFAULT NULL,
  `actualizado_por_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_codigo` (`codigo`),
  KEY `idx_nombre` (`nombre`),
  KEY `idx_categoria` (`categoria`),
  KEY `idx_proveedor` (`proveedor_id`),
  KEY `fk_ref_creador` (`creado_por_id`),
  KEY `fk_ref_actualizador` (`actualizado_por_id`),
  CONSTRAINT `fk_ref_actualizador` FOREIGN KEY (`actualizado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ref_creador` FOREIGN KEY (`creado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ref_proveedor` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refacciones`
--

LOCK TABLES `refacciones` WRITE;
/*!40000 ALTER TABLE `refacciones` DISABLE KEYS */;
INSERT INTO `refacciones` VALUES (1,'REF-01','Rodamiento 6205','Refaccion de prueba','GDO','nuevo','SKF','Mecánica','pieza',10.00,NULL,NULL,1,1,1,'2026-05-28 23:48:32','2026-05-28 23:48:32');
/*!40000 ALTER TABLE `refacciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refacciones_compatibles`
--

DROP TABLE IF EXISTS `refacciones_compatibles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refacciones_compatibles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refaccion_id` int(11) NOT NULL,
  `equipo_id` int(11) DEFAULT NULL,
  `componente_id` int(11) DEFAULT NULL,
  `notas` varchar(255) DEFAULT NULL COMMENT 'ej. Para etapa 2, lado izquierdo',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ref_equipo` (`refaccion_id`,`equipo_id`),
  UNIQUE KEY `uk_ref_componente` (`refaccion_id`,`componente_id`),
  KEY `idx_equipo` (`equipo_id`),
  KEY `idx_componente` (`componente_id`),
  CONSTRAINT `fk_comp_componente_compat` FOREIGN KEY (`componente_id`) REFERENCES `equipo_componentes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_comp_equipo_compat` FOREIGN KEY (`equipo_id`) REFERENCES `equipos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_comp_refaccion` FOREIGN KEY (`refaccion_id`) REFERENCES `refacciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refacciones_compatibles`
--

LOCK TABLES `refacciones_compatibles` WRITE;
/*!40000 ALTER TABLE `refacciones_compatibles` DISABLE KEYS */;
INSERT INTO `refacciones_compatibles` VALUES (1,1,NULL,1,'vinculacion de prueba','2026-05-29 04:50:59'),(2,1,1,NULL,'Auto-vinculada desde INC-BAC-2026-0001','2026-05-29 04:52:52');
/*!40000 ALTER TABLE `refacciones_compatibles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refacciones_movimientos`
--

DROP TABLE IF EXISTS `refacciones_movimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refacciones_movimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refaccion_id` int(11) NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `tipo` enum('entrada','salida','ajuste','transferencia') NOT NULL,
  `cantidad` decimal(10,2) NOT NULL COMMENT 'Positivo siempre, el tipo define el signo',
  `cantidad_antes` decimal(10,2) NOT NULL,
  `cantidad_despues` decimal(10,2) NOT NULL,
  `motivo` varchar(80) DEFAULT NULL COMMENT 'compra, devolucion, uso_mantenimiento, ajuste_inventario, merma',
  `notas` text DEFAULT NULL,
  `incidencia_id` int(11) DEFAULT NULL COMMENT 'Si el movimiento es por una orden de trabajo',
  `componente_id` int(11) DEFAULT NULL COMMENT 'Si reemplaza un componente específico',
  `sucursal_destino_id` int(11) DEFAULT NULL,
  `costo_unitario` decimal(10,2) DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_refaccion` (`refaccion_id`,`creado_en`),
  KEY `idx_sucursal` (`sucursal_id`,`creado_en`),
  KEY `idx_incidencia` (`incidencia_id`),
  KEY `idx_tipo` (`tipo`,`creado_en`),
  KEY `fk_mov_suc_destino` (`sucursal_destino_id`),
  KEY `fk_mov_componente` (`componente_id`),
  KEY `fk_mov_usuario` (`usuario_id`),
  CONSTRAINT `fk_mov_componente` FOREIGN KEY (`componente_id`) REFERENCES `equipo_componentes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mov_incidencia` FOREIGN KEY (`incidencia_id`) REFERENCES `incidencias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mov_refaccion` FOREIGN KEY (`refaccion_id`) REFERENCES `refacciones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mov_suc_destino` FOREIGN KEY (`sucursal_destino_id`) REFERENCES `sucursales` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mov_sucursal` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mov_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refacciones_movimientos`
--

LOCK TABLES `refacciones_movimientos` WRITE;
/*!40000 ALTER TABLE `refacciones_movimientos` DISABLE KEYS */;
INSERT INTO `refacciones_movimientos` VALUES (3,1,1,'entrada',10.00,0.00,10.00,'compra','Adicion de prueba',NULL,NULL,NULL,NULL,1,'2026-05-29 04:35:54'),(4,1,1,'salida',1.00,10.00,9.00,'uso_mantenimiento','Usada en orden INC-BAC-2026-0001: Falla Inicial prueba del sistema',37,1,NULL,10.00,1,'2026-05-29 04:52:52');
/*!40000 ALTER TABLE `refacciones_movimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refacciones_stock`
--

DROP TABLE IF EXISTS `refacciones_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refacciones_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refaccion_id` int(11) NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `cantidad_actual` decimal(10,2) NOT NULL DEFAULT 0.00,
  `cantidad_minima` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Alerta cuando stock <= mínimo',
  `cantidad_optima` decimal(10,2) DEFAULT NULL COMMENT 'Cantidad ideal sugerida',
  `ubicacion` varchar(150) DEFAULT NULL COMMENT 'ej. Anaquel A-3, Pasillo 2, Caja 14',
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_refaccion_sucursal` (`refaccion_id`,`sucursal_id`),
  KEY `idx_sucursal` (`sucursal_id`),
  KEY `idx_stock_bajo` (`sucursal_id`,`cantidad_actual`),
  CONSTRAINT `fk_stock_refaccion` FOREIGN KEY (`refaccion_id`) REFERENCES `refacciones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_stock_sucursal` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refacciones_stock`
--

LOCK TABLES `refacciones_stock` WRITE;
/*!40000 ALTER TABLE `refacciones_stock` DISABLE KEYS */;
INSERT INTO `refacciones_stock` VALUES (1,1,1,9.00,5.00,15.00,'Oficina','2026-05-29 04:52:52');
/*!40000 ALTER TABLE `refacciones_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reglas_asignacion`
--

DROP TABLE IF EXISTS `reglas_asignacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reglas_asignacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL COMMENT 'Nombre descriptivo de la regla',
  `descripcion` varchar(255) DEFAULT NULL,
  `sucursal_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `tipo_trabajo_id` int(11) DEFAULT NULL,
  `severidad_id` int(11) DEFAULT NULL,
  `asignar_a_id` int(11) NOT NULL,
  `prioridad` int(11) NOT NULL DEFAULT 100 COMMENT 'Menor = se evalúa antes',
  `activa` tinyint(1) NOT NULL DEFAULT 1,
  `veces_aplicada` int(11) NOT NULL DEFAULT 0,
  `creado_por_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activa_prioridad` (`activa`,`prioridad`),
  KEY `idx_sucursal` (`sucursal_id`),
  KEY `idx_area` (`area_id`),
  KEY `fk_regla_categoria` (`categoria_id`),
  KEY `fk_regla_tipo` (`tipo_trabajo_id`),
  KEY `fk_regla_severidad` (`severidad_id`),
  KEY `fk_regla_asignar` (`asignar_a_id`),
  KEY `fk_regla_creador` (`creado_por_id`),
  CONSTRAINT `fk_regla_area` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_regla_asignar` FOREIGN KEY (`asignar_a_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_regla_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_regla_creador` FOREIGN KEY (`creado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_regla_severidad` FOREIGN KEY (`severidad_id`) REFERENCES `severidades` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_regla_sucursal` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_regla_tipo` FOREIGN KEY (`tipo_trabajo_id`) REFERENCES `tipos_trabajo` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reglas_asignacion`
--

LOCK TABLES `reglas_asignacion` WRITE;
/*!40000 ALTER TABLE `reglas_asignacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `reglas_asignacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `puede_administrar` tinyint(1) NOT NULL DEFAULT 0,
  `puede_ver_todas_sucursales` tinyint(1) NOT NULL DEFAULT 0,
  `puede_resolver` tinyint(1) NOT NULL DEFAULT 0,
  `puede_crear_solicitud` tinyint(1) NOT NULL DEFAULT 1,
  `puede_ver_reportes` tinyint(1) NOT NULL DEFAULT 0,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','Control total del sistema, configura todo',1,1,1,1,1,1,'2026-01-01 00:00:00'),(2,'Técnico de Mantenimiento','Atiende y resuelve órdenes de trabajo en todas las plantas',0,1,1,1,1,1,'2026-01-01 00:00:00'),(3,'Supervisor de Planta','Supervisa su planta y genera reportes',0,0,0,1,1,1,'2026-01-01 00:00:00'),(4,'Operador / Reportante','Reporta fallas y da seguimiento a las órdenes de su área',0,0,0,1,0,1,'2026-01-01 00:00:00'),(5,'Solo Lectura','Consulta y filtra sin modificar',0,1,0,0,1,1,'2026-01-01 00:00:00'),(7,'Arquitecto','Arquitecto de planta con permisos completos: gestiona catálogos, equipos, refacciones, herramientas, proveedores y atiende órdenes en todas las plantas',1,1,1,1,1,1,'2026-05-29 11:21:49');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sesiones`
--

DROP TABLE IF EXISTS `sesiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sesiones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `session_id` varchar(128) NOT NULL COMMENT 'PHP session_id()',
  `ip` varchar(45) DEFAULT NULL COMMENT 'IPv4 o IPv6',
  `user_agent` varchar(500) DEFAULT NULL,
  `dispositivo` varchar(100) DEFAULT NULL COMMENT 'Dispositivo detectado (Windows, Mac, Android, iPhone, etc)',
  `navegador` varchar(50) DEFAULT NULL COMMENT 'Navegador detectado',
  `activa` tinyint(1) NOT NULL DEFAULT 1,
  `motivo_cierre` varchar(100) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultima_actividad` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cerrada_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_session_id` (`session_id`),
  KEY `idx_usuario_activa` (`usuario_id`,`activa`),
  KEY `idx_creado` (`creado_en`),
  CONSTRAINT `fk_sesion_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sesiones`
--

LOCK TABLES `sesiones` WRITE;
/*!40000 ALTER TABLE `sesiones` DISABLE KEYS */;
INSERT INTO `sesiones` VALUES (19,1,'ajk533o70ebqu1j0kcqdthamhi','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','Windows 10/11','Chrome',0,'logout normal','2026-05-28 23:28:04','2026-05-28 23:28:06','2026-05-28 23:28:06'),(20,1,'6l3qet19krae15f02pgeo4hai8','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','Windows 10/11','Chrome',0,'logout normal','2026-05-28 23:28:12','2026-05-28 23:28:33','2026-05-28 23:28:33'),(21,1,'cl10oas48aq5qdjm1hpnfd1rqa','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','Windows 10/11','Chrome',1,NULL,'2026-05-28 23:28:39','2026-05-29 01:15:08',NULL),(22,1,'8rheera2jt23d45qu60jlf0pov','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','Windows 10/11','Chrome',1,NULL,'2026-05-29 04:34:49','2026-05-29 08:57:08',NULL),(23,1,'7osuf1q0r40v97r9jajl9cngun','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','Windows 10/11','Chrome',1,NULL,'2026-05-29 17:49:57','2026-05-30 04:39:08',NULL),(24,1,'flclbcj710cuotuiekgdu91b6b','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','Windows 10/11','Chrome',1,NULL,'2026-05-31 14:46:59','2026-05-31 15:20:09',NULL),(25,1,'cejceoj6oairouh2j82qralgj5','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','Windows 10/11','Chrome',1,NULL,'2026-05-31 17:23:51','2026-05-31 17:24:38',NULL),(26,1,'215m5q5bg0hjai7g6ulqo1vi02','192.168.1.84','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','Windows 10/11','Chrome',1,NULL,'2026-06-01 22:05:45','2026-06-02 00:03:48',NULL),(27,1,'er13qu91nk93l0k2qnm1avnars','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','Windows 10/11','Chrome',0,'logout normal','2026-06-01 23:27:08','2026-06-01 23:30:19','2026-06-01 23:30:19'),(28,1,'kr3tih5eua29c9maghag33rnho','192.168.1.19','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','Windows 10/11','Chrome',1,NULL,'2026-06-01 23:33:06','2026-06-02 03:36:10',NULL);
/*!40000 ALTER TABLE `sesiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `severidades`
--

DROP TABLE IF EXISTS `severidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `severidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `nivel` int(11) NOT NULL,
  `color` varchar(20) NOT NULL DEFAULT '#6B7280',
  `sla_horas` int(11) DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`),
  UNIQUE KEY `nivel` (`nivel`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `severidades`
--

LOCK TABLES `severidades` WRITE;
/*!40000 ALTER TABLE `severidades` DISABLE KEYS */;
INSERT INTO `severidades` VALUES (1,'Crítica',1,'#DC2626',2,'Línea o equipo crítico detenido, afecta producción',1),(2,'Alta',2,'#EA580C',8,'Afecta producción pero hay alternativas',1),(3,'Media',3,'#D97706',24,'Sin afectación inmediata a producción',1),(4,'Baja',4,'#16A34A',72,'Programable, sin urgencia',1);
/*!40000 ALTER TABLE `severidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcategorias`
--

DROP TABLE IF EXISTS `subcategorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcategorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_categoria_nombre` (`categoria_id`,`nombre`),
  CONSTRAINT `subcategorias_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcategorias`
--

LOCK TABLES `subcategorias` WRITE;
/*!40000 ALTER TABLE `subcategorias` DISABLE KEYS */;
/*!40000 ALTER TABLE `subcategorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sucursal_plantas`
--

DROP TABLE IF EXISTS `sucursal_plantas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sucursal_plantas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sucursal_id` int(11) NOT NULL,
  `nombre` varchar(80) NOT NULL COMMENT 'Ej: Planta baja, Piso 1, Bodega',
  `orden` int(11) NOT NULL DEFAULT 0 COMMENT 'Para ordenar las pestañas',
  `plano_url` varchar(255) DEFAULT NULL,
  `plano_subido_en` timestamp NULL DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sucursal` (`sucursal_id`,`orden`),
  CONSTRAINT `fk_planta_sucursal` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sucursal_plantas`
--

LOCK TABLES `sucursal_plantas` WRITE;
/*!40000 ALTER TABLE `sucursal_plantas` DISABLE KEYS */;
/*!40000 ALTER TABLE `sucursal_plantas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sucursales`
--

DROP TABLE IF EXISTS `sucursales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sucursales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(50) DEFAULT NULL,
  `responsable` varchar(150) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` datetime DEFAULT current_timestamp(),
  `actualizado_en` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sucursales`
--

LOCK TABLES `sucursales` WRITE;
/*!40000 ALTER TABLE `sucursales` DISABLE KEYS */;
INSERT INTO `sucursales` VALUES (1,'Bacal','BAC','Av. Cruz del Sur 2025, Fracc. Las Huertas 3ra. Sección, Tijuana','(664) 972 06 31','Alberto Martinez',1,'2026-01-01 00:00:00','2026-01-01 00:00:00'),(2,'Ferias','FER','De las Ferias 84, Lomas Hipodromo, 22030 Tijuana, B.C.','664 104 1093','Omar',1,'2026-01-01 00:00:00','2026-01-01 00:00:00');
/*!40000 ALTER TABLE `sucursales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_trabajo`
--

DROP TABLE IF EXISTS `tipos_trabajo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipos_trabajo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `color` varchar(20) DEFAULT '#6B7280',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_trabajo`
--

LOCK TABLES `tipos_trabajo` WRITE;
/*!40000 ALTER TABLE `tipos_trabajo` DISABLE KEYS */;
INSERT INTO `tipos_trabajo` VALUES (15,'Correctivo',NULL,'#DC2626',1,'2026-05-28 16:10:57'),(16,'Preventivo',NULL,'#10B981',1,'2026-05-28 16:10:57'),(17,'Predictivo',NULL,'#3B82F6',1,'2026-05-28 16:10:57'),(18,'Calibración',NULL,'#F59E0B',1,'2026-05-28 16:10:57'),(19,'Inspección',NULL,'#06B6D4',1,'2026-05-28 16:10:57'),(20,'Limpieza',NULL,'#84CC16',1,'2026-05-28 16:10:57'),(21,'Lubricación',NULL,'#8B5CF6',1,'2026-05-28 16:10:57'),(22,'Instalación',NULL,'#71717a',1,'2026-05-28 16:10:57'),(23,'Modificación/Mejora',NULL,'#EC4899',1,'2026-05-28 16:10:57'),(24,'Emergencia',NULL,'#991B1B',1,'2026-05-28 16:10:57');
/*!40000 ALTER TABLE `tipos_trabajo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `nombre_completo` varchar(150) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `avatar_url` varchar(255) DEFAULT NULL COMMENT 'Ruta relativa de la foto de perfil',
  `pagina_inicio_preferida` varchar(100) DEFAULT 'dashboard.php',
  `telefono` varchar(50) DEFAULT NULL,
  `rol_id` int(11) NOT NULL,
  `sucursal_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `puesto` varchar(100) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `ultimo_login` datetime DEFAULT NULL,
  `intentos_fallidos` int(11) NOT NULL DEFAULT 0,
  `bloqueado_hasta` datetime DEFAULT NULL,
  `debe_cambiar_password` tinyint(1) NOT NULL DEFAULT 0,
  `creado_en` datetime DEFAULT current_timestamp(),
  `actualizado_en` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `rol_id` (`rol_id`),
  KEY `idx_usuario_activo` (`usuario`,`activo`),
  KEY `idx_sucursal` (`sucursal_id`),
  KEY `idx_area` (`area_id`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`) ON DELETE SET NULL,
  CONSTRAINT `usuarios_ibfk_3` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'admin','$2y$10$b/bRauD2B46ffwr1R8p5Y.taYWiNLWVIb85iCfn.hwoL0w.9g5GzG','Administrador del Sistema','admin@carnesbacal.com',NULL,'dashboard.php',NULL,1,NULL,NULL,'Administrador',NULL,1,'2026-06-01 16:33:06',0,NULL,0,'2026-01-01 00:00:00','2026-06-01 16:33:06'),(17,'lfrodriguez','$2y$10$ZzO6C/ykDcXRljJK8.gLB.BWz7qvJ/MTLkCumPZ4B.dyI0SdmyvCO','Luis Fernando Rodriguez Cruz','lfrodriguez@granodeoro.com.mx',NULL,'dashboard.php','6642382390',1,NULL,NULL,'Encargado de Sistemas',NULL,1,NULL,0,NULL,1,'2026-05-29 10:52:53','2026-05-29 10:52:53'),(18,'njmartinez','$2y$10$8B.vKkDcyD6DuiygaxA7DOLm5G6t8LowmV49FMw2TCqL8eoWf/M8e','Noe Julian Martinez','njmartinez@granodeoro.com.mx',NULL,'dashboard.php',NULL,7,NULL,NULL,'Proyectos Especiales',NULL,1,NULL,0,NULL,1,'2026-06-01 16:34:25','2026-06-01 16:34:25'),(19,'jamartinez','$2y$10$.sTZX8HZWWW8Ug7ZS.AkeOsfp1LS1U93SFJyTLfPLTYtwJ6JxlULS','Jose Alberto Martinez','jamartinez@granodeoro.com.mx',NULL,'dashboard.php',NULL,3,1,NULL,'Gerente de Tienda',NULL,1,NULL,0,NULL,1,'2026-06-01 16:35:21','2026-06-01 16:35:21'),(20,'jlcorral','$2y$10$jz30.mmKt9sgK1l4afpl2OP5jeX9ZRVHsf2kHNQMvQmM/VnLVtufm','Jose Luis Corral Terrazas','jlcorral@granodeoro.com.mx',NULL,'dashboard.php',NULL,1,NULL,NULL,'Administrador',NULL,1,NULL,0,NULL,1,'2026-06-01 16:36:24','2026-06-01 16:36:24');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_accesos`
--

DROP TABLE IF EXISTS `vault_accesos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vault_accesos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrada_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `accion` enum('ver_password','copiar_password','ver_entrada') NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_entrada` (`entrada_id`,`creado_en`),
  KEY `idx_usuario` (`usuario_id`,`creado_en`),
  CONSTRAINT `fk_acc_entrada` FOREIGN KEY (`entrada_id`) REFERENCES `vault_entradas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_acc_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_accesos`
--

LOCK TABLES `vault_accesos` WRITE;
/*!40000 ALTER TABLE `vault_accesos` DISABLE KEYS */;
/*!40000 ALTER TABLE `vault_accesos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_categorias`
--

DROP TABLE IF EXISTS `vault_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vault_categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `familia` varchar(60) NOT NULL COMMENT 'Grupo visual: Acceso, Infraestructura, etc.',
  `familia_orden` int(11) NOT NULL DEFAULT 0,
  `nombre` varchar(100) NOT NULL,
  `icono` varchar(50) DEFAULT 'folder',
  `color` varchar(20) DEFAULT '#71717a',
  `orden` int(11) NOT NULL DEFAULT 0,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_familia` (`familia`,`orden`),
  KEY `idx_orden` (`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_categorias`
--

LOCK TABLES `vault_categorias` WRITE;
/*!40000 ALTER TABLE `vault_categorias` DISABLE KEYS */;
INSERT INTO `vault_categorias` VALUES (36,'Mecánica',1,'Manuales de fabricante (mecánica)','book-open','#DC2626',1,1,'2026-05-28 23:10:57'),(37,'Mecánica',1,'Despieces y explosionados','layers','#B91C1C',2,1,'2026-05-28 23:10:57'),(38,'Mecánica',1,'Fichas técnicas de equipos','file-text','#991B1B',3,1,'2026-05-28 23:10:57'),(39,'Eléctrica',2,'Planos eléctricos','workflow','#F59E0B',10,1,'2026-05-28 23:10:57'),(40,'Eléctrica',2,'Diagramas de tableros','layout-grid','#D97706',11,1,'2026-05-28 23:10:57'),(41,'Eléctrica',2,'Esquemas unifilares','git-branch','#B45309',12,1,'2026-05-28 23:10:57'),(42,'Refrigeración',3,'Manuales de compresores','snowflake','#06B6D4',20,1,'2026-05-28 23:10:57'),(43,'Refrigeración',3,'Cartas de refrigerante','thermometer','#0891B2',21,1,'2026-05-28 23:10:57'),(44,'Refrigeración',3,'Curvas presión-temperatura','line-chart','#0E7490',22,1,'2026-05-28 23:10:57'),(45,'Hidráulica/Neumática',4,'Manuales hidráulicos y neumáticos','droplet','#3B82F6',30,1,'2026-05-28 23:10:57'),(46,'Hidráulica/Neumática',4,'Diagramas de circuitos','workflow','#2563EB',31,1,'2026-05-28 23:10:57'),(47,'Hidráulica/Neumática',4,'Hojas técnicas de bombas','gauge','#1D4ED8',32,1,'2026-05-28 23:10:57'),(48,'Seguridad',5,'MSDS / Hojas de seguridad','shield-alert','#EF4444',40,1,'2026-05-28 23:10:57'),(49,'Seguridad',5,'Protocolos y procedimientos seguros','shield-check','#DC2626',41,1,'2026-05-28 23:10:57'),(50,'Seguridad',5,'Bloqueo y etiquetado (LOTO)','lock','#991B1B',42,1,'2026-05-28 23:10:57'),(51,'Equipos críticos',6,'Garantías de equipos','badge-check','#10B981',50,1,'2026-05-28 23:10:57'),(52,'Equipos críticos',6,'Pólizas de servicio','file-check','#059669',51,1,'2026-05-28 23:10:57'),(53,'Equipos críticos',6,'Contactos de servicio especializado','phone','#047857',52,1,'2026-05-28 23:10:57'),(54,'Calibraciones',7,'Certificados de calibración','award','#8B5CF6',60,1,'2026-05-28 23:10:57'),(55,'Calibraciones',7,'Bitácora de calibraciones','clipboard-list','#7C3AED',61,1,'2026-05-28 23:10:57'),(56,'Calibraciones',7,'Patrones y trazabilidad','ruler','#6D28D9',62,1,'2026-05-28 23:10:57'),(57,'Refacciones',8,'Catálogos de refacciones','book','#F59E0B',70,1,'2026-05-28 23:10:57'),(58,'Refacciones',8,'Listas maestras','list','#D97706',71,1,'2026-05-28 23:10:57'),(59,'Refacciones',8,'Equivalencias entre marcas','arrow-left-right','#B45309',72,1,'2026-05-28 23:10:57'),(60,'Procedimientos',9,'Arranque y paro de equipos','power','#0EA5E9',80,1,'2026-05-28 23:10:57'),(61,'Procedimientos',9,'Limpieza CIP/SIP','spray-can','#0284C7',81,1,'2026-05-28 23:10:57'),(62,'Procedimientos',9,'Cambios de turno','clock','#0369A1',82,1,'2026-05-28 23:10:57'),(63,'Reportes',10,'Plantillas de reporte','file-spreadsheet','#16A34A',90,1,'2026-05-28 23:10:57'),(64,'Reportes',10,'Bitácoras maestras','book-open','#15803D',91,1,'2026-05-28 23:10:57'),(65,'Reportes',10,'Inventarios','boxes','#166534',92,1,'2026-05-28 23:10:57'),(66,'Legal y administrativo',11,'Permisos y licencias','file-badge','#7C2D12',100,1,'2026-05-28 23:10:57'),(67,'Legal y administrativo',11,'Certificaciones (ISO, etc.)','award','#92400E',101,1,'2026-05-28 23:10:57'),(68,'Legal y administrativo',11,'Auditorías y dictámenes','gavel','#78350F',102,1,'2026-05-28 23:10:57'),(69,'General',12,'Acceso rápido','star','#EAB308',110,1,'2026-05-28 23:10:57'),(70,'General',12,'Otros / Archivado','archive','#71717A',111,1,'2026-05-28 23:10:57');
/*!40000 ALTER TABLE `vault_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_entradas`
--

DROP TABLE IF EXISTS `vault_entradas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vault_entradas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_id` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `url` varchar(500) DEFAULT NULL,
  `usuario` varchar(200) DEFAULT NULL,
  `password_cifrado` text DEFAULT NULL COMMENT 'AES-256 encrypted',
  `notas` text DEFAULT NULL COMMENT 'Markdown libre',
  `archivos` text DEFAULT NULL COMMENT 'Rutas UNC u observaciones, editable',
  `version_build` varchar(100) DEFAULT NULL COMMENT 'Para instaladores/drivers',
  `vencimiento` date DEFAULT NULL COMMENT 'Para licencias/certificados',
  `tags` varchar(500) DEFAULT NULL COMMENT 'Coma-separadas',
  `sucursal_id` int(11) DEFAULT NULL COMMENT 'NULL = todas / N/A',
  `sensibilidad` enum('normal','alta','critica') NOT NULL DEFAULT 'normal',
  `permisos_tipo` enum('todos','rol','sucursal','usuarios','admin') NOT NULL DEFAULT 'admin' COMMENT 'todos=visible para todos / rol=por roles_ids / sucursal=por sucursales_ids / usuarios=lista específica / admin=solo admin',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_por_id` int(11) DEFAULT NULL,
  `actualizado_por_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_categoria` (`categoria_id`),
  KEY `idx_sucursal` (`sucursal_id`),
  KEY `idx_nombre` (`nombre`),
  KEY `idx_activo` (`activo`),
  KEY `fk_vault_creador` (`creado_por_id`),
  KEY `fk_vault_actualizador` (`actualizado_por_id`),
  CONSTRAINT `fk_vault_actualizador` FOREIGN KEY (`actualizado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vault_cat` FOREIGN KEY (`categoria_id`) REFERENCES `vault_categorias` (`id`),
  CONSTRAINT `fk_vault_creador` FOREIGN KEY (`creado_por_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vault_suc` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_entradas`
--

LOCK TABLES `vault_entradas` WRITE;
/*!40000 ALTER TABLE `vault_entradas` DISABLE KEYS */;
/*!40000 ALTER TABLE `vault_entradas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_favoritos`
--

DROP TABLE IF EXISTS `vault_favoritos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vault_favoritos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrada_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_entrada_usuario` (`entrada_id`,`usuario_id`),
  KEY `fk_fav_usuario` (`usuario_id`),
  CONSTRAINT `fk_fav_entrada` FOREIGN KEY (`entrada_id`) REFERENCES `vault_entradas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fav_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_favoritos`
--

LOCK TABLES `vault_favoritos` WRITE;
/*!40000 ALTER TABLE `vault_favoritos` DISABLE KEYS */;
/*!40000 ALTER TABLE `vault_favoritos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_historial`
--

DROP TABLE IF EXISTS `vault_historial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vault_historial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrada_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `accion` enum('crear','editar','eliminar','password_cambiada','permisos_cambiados') NOT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_entrada` (`entrada_id`,`creado_en`),
  KEY `fk_hist_usuario` (`usuario_id`),
  CONSTRAINT `fk_hist_entrada` FOREIGN KEY (`entrada_id`) REFERENCES `vault_entradas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hist_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_historial`
--

LOCK TABLES `vault_historial` WRITE;
/*!40000 ALTER TABLE `vault_historial` DISABLE KEYS */;
/*!40000 ALTER TABLE `vault_historial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_permisos`
--

DROP TABLE IF EXISTS `vault_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vault_permisos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrada_id` int(11) NOT NULL,
  `tipo` enum('rol','usuario','sucursal') NOT NULL,
  `referencia_id` int(11) NOT NULL COMMENT 'ID del rol, usuario o sucursal',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_entrada_tipo_ref` (`entrada_id`,`tipo`,`referencia_id`),
  KEY `idx_entrada` (`entrada_id`),
  CONSTRAINT `fk_perm_entrada` FOREIGN KEY (`entrada_id`) REFERENCES `vault_entradas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_permisos`
--

LOCK TABLES `vault_permisos` WRITE;
/*!40000 ALTER TABLE `vault_permisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `vault_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mantenimiento_bacal'
--

--
-- Dumping routines for database 'mantenimiento_bacal'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-02 11:15:45
